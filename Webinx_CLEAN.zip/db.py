import sqlite3

DB_NAME = "webinx.db"


def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS webinars (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            event_date TEXT NOT NULL,
            country TEXT,
            final_rank REAL,
            UNIQUE(title, event_date)
        )
    """)

    # === PERFORMANCE INDEXES ===
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_title ON webinars(title)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_country ON webinars(country)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_event_date ON webinars(event_date)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_rank ON webinars(final_rank)")

    conn.commit()
    conn.close()


def get_events(query="", country=""):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "SELECT * FROM webinars WHERE 1=1"
    params = []

    if query:
        sql += " AND title LIKE ?"
        params.append(f"%{query}%")

    if country:
        sql += " AND country = ?"
        params.append(country)

    sql += " ORDER BY final_rank DESC"

    cursor.execute(sql, params)
    rows = cursor.fetchall()
    conn.close()

    return [dict(row) for row in rows]
