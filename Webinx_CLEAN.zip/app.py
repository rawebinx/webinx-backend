from flask import Flask, render_template, request
from db import get_events, init_db

app = Flask(__name__)

# Initialize DB immediately
init_db()


@app.route("/")
def index():
    try:
        query = request.args.get("query", "").strip()
        country = request.args.get("country", "").strip()

        events = get_events(query=query, country=country)

        return render_template(
            "index.html",
            events=events,
            query=query,
            country=country
        )

    except Exception as e:
        print("Error loading homepage:", e)
        return "Internal server error", 500


@app.errorhandler(404)
def not_found(e):
    return "Page not found", 404


@app.errorhandler(500)
def internal_error(e):
    return "Internal server error", 500


if __name__ == "__main__":
    app.run(debug=False)
