def calculate_rank(event):
    score = 0

    title = event.get("title", "").lower()

    if "ai" in title:
        score += 15

    if "tender" in title:
        score += 12

    if "construction" in title:
        score += 10

    score += 5  # base score

    return float(score)
