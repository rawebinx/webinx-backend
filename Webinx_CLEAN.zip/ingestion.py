import json
from datetime import datetime
from db import get_connection, init_db
from intelligence import calculate_rank


LOG_FILE = "logs/import.log"


def log_message(message):
    with open(LOG_FILE, "a", encoding="utf-8") as log:
        log.write(message + "\n")


def is_valid_date(date_string):
    try:
        datetime.strptime(date_string, "%Y-%m-%d")
        return True
    except:
        return False


def ingest():
    try:
        init_db()
        conn = get_connection()
        cursor = conn.cursor()

        try:
            with open("data/sample_data.json", "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            log_message(f"ERROR: Failed loading JSON → {str(e)}")
            print("JSON loading failed. Check logs.")
            return

        inserted_count = 0
        skipped_duplicates = 0
        skipped_invalid = 0

        for event in data:
            try:
                title = event.get("title")
                event_date = event.get("event_date")
                country = event.get("country")

                # Validation
                if not title or not event_date or not country:
                    skipped_invalid += 1
                    log_message(f"INVALID: Missing field → {event}")
                    continue

                if not is_valid_date(event_date):
                    skipped_invalid += 1
                    log_message(f"INVALID: Wrong date format → {event}")
                    continue

                # Duplicate Check
                cursor.execute("""
                    SELECT id FROM webinars
                    WHERE title = ? AND event_date = ?
                """, (title, event_date))

                if cursor.fetchone():
                    skipped_duplicates += 1
                    continue

                # Ranking
                rank = calculate_rank(event)

                # Insert
                cursor.execute("""
                    INSERT INTO webinars (title, event_date, country, final_rank)
                    VALUES (?, ?, ?, ?)
                """, (
                    title,
                    event_date,
                    country,
                    rank
                ))

                inserted_count += 1

            except Exception as row_error:
                skipped_invalid += 1
                log_message(f"ROW ERROR: {str(row_error)} → {event}")
                continue

        conn.commit()
        conn.close()

        summary = (
            f"RUN SUMMARY → Inserted: {inserted_count}, "
            f"Duplicates: {skipped_duplicates}, "
            f"Invalid: {skipped_invalid}"
        )

        print("Ingestion completed.")
        print(summary)
        log_message(summary)

    except Exception as fatal_error:
        log_message(f"FATAL ERROR: {str(fatal_error)}")
        print("Fatal error occurred. Check logs.")


if __name__ == "__main__":
    ingest()
